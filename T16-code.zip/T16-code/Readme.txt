#####################################
## Project Requirment For Running  ## 
#####################################
Setup
1.python
2.Jupyter Notbook

#####################################
##  Package installition           ##          
#####################################
1. install openCV  pip install openCv
2. install  progressbar pip install progressbar
3. install numba pip install numba  
4. install numpy pip install numpy
############################################
##   How to use Face Cartooniztion        ##        
############################################

1.get DataSet For training (faces/nofaces) From Links in Report((optinal) For training ) 
2.open Notebook Adaboost_Training.ipynb and run all cells to train and get File classifierData.txt
Which has training Results (Viola jones Features) ((optianal) for new training results)
3.open Notebook FaceDetection.ipynb and run all cells 
4.then check you have a camera in your device 
5.enjoy with Cartoon face filter in your face 

